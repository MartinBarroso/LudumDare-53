using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GPS : MonoBehaviour
{
   [SerializeField] private GameObject origin;
   [SerializeField] private GameObject house;
   [SerializeField] private Transform[] houseLocations;
   [SerializeField] private Transform[] dinnerLocations;
   private GameManager game;
    void Update()
    {
        
    }
}
